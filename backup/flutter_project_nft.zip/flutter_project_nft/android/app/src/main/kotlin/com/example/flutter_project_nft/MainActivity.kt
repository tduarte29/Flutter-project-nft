package com.example.flutter_project_nft

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
